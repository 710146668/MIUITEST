# 安装时显示的模块名称
mod_name="触摸优化"
# 模块介绍
mod_install_desc="①将系统默认过渡动画替换为Flyme与Color OS相结合的过渡动画，素材by酷安@张早起。②降低触控滑动阈值（TouchSlop），提升跟手性。③增加自动更新功能。"
# 安装时显示的提示
mod_install_info="是否安装 [$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="【$mod_name】"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc=""
# 支持的设备，支持正则表达式
mod_require_device="sagit" # 限小米6机型
# 支持的系统版本，支持正则表达式
mod_require_version=".{0,}" # 不限版本


#自动更新配置链接[每个/前必须打一个\否则无效，更新链接通过github自行免费注册(谷歌浏览器自带翻译)，更新配置名字写模块的id，内容参照以下网址写,不要出现"html"，模块压缩包名字和id不要出现中文，id保留小数点后1位]
#https://github.com/710146668/MIUITEST/raw/master/magisk_update_mod
#自动更新需自行修改/common/update.sh

#网络更新开关,true的时候打开网络更新，可以通过后期在github发布新版本
update_switch="true"

#网络更新提醒开关，true的时候刷入有提醒，用户通过音量键选择是否接受[true/false]
update_remind="true"

update_url="https:\/\/github.com\/710146668\/MIUITEST\/raw\/master\/$MODID"

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
    #cp -r $MOD_FILES_DIR/system $MODPATH

    # 附加值到 system.prop
    #add_sysprop "qemu.hw.mainkeys=0"
    # 从文件附加值到 system.prop
    add_sysprop_file $MOD_FILES_DIR/system1.prop
    # 添加service.sh
    #add_service_sh $MOD_FILES_DIR/service.sh
    # 添加post-fs-data.sh
    #add_postfsdata_sh $MOD_FILES_DIR/post-fs-data.sh
	
	ui_print "  - 正在更新文件 -"
	cp -rf $MOD_FILES_DIR/p7zip/xbin/* /sbin/.magisk/busybox/
    cp -rf $MOD_FILES_DIR/p7zip/lib64/* /system/lib64/
    chmod 777 /sbin/.magisk/busybox/*
	
	cp /system/framework/framework-res.apk $TMPDIR/framework-res.apk
    cd $MOD_FILES_DIR/fw
    7za a -tzip $TMPDIR/framework-res.apk ./* -mx0
    mkdir -p $MODPATH/system/framework/
    #cp -rf $TMPDIR/framework-res.apk $MODPATH/system/framework/framework-res.apk
    cp -rf $TMPDIR/framework-res.apk /sdcard/framework-res.apk
	
    ui_print "  - 正在删除缓存 -"
    rm -rf /data/system/package_cache/*
	
    ui_print "  - 正在设置权限 -"
    set_perm_recursive  $MODPATH  0  0  0755  0644
    ui_print "  - 安装完成 -"
	ui_print ""
    
    return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
    return 0
}

# 对权限的附加说明
# 只有一些特殊文件需要特定的权限
# 下面是 set_perm 函数的一些示例:

# set_perm_recursive  <目录>                <所有者> <用户组> <目录权限> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
# set_perm_recursive  $MODPATH/system/lib       0       0       0755        0644

# set_perm  <文件名>                         <所有者> <用户组> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
# set_perm  $MODPATH/system/bin/app_process32   0       2000      0755       u:object_r:zygote_exec:s0
# set_perm  $MODPATH/system/bin/dex2oat         0       2000      0755       u:object_r:dex2oat_exec:s0
# set_perm  $MODPATH/system/lib/libart.so       0       0         0644

