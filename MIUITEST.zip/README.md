# MIUITEST
小米6个性功能测试

### License
- [MIT](LICENSE)

### Latest version: V1.2

### 使用方法请查看以下文件
- [酷安上的教程](https://www.coolapk.com/feed/13561743?shareKey=YWNiY2Y0MmM3MTg1NWQ2ODY5MjQ~&shareUid=800048&shareFrom=com.coolapk.market_9.4.1)
