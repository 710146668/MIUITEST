#!/system/bin/sh
until [ $(getprop sys.boot_completed) -eq 1 ]
do 
    sleep 2
done
sleep 30
mod_id="ididididid"
path="/storage/emulated/0/$mod_id.log"
if [ ! -d "/data/adb/modules/$mod_id" ];then
  rm -rf /data/adb/service.d/$mod_id
else  
  var=`sed -n 3p /data/adb/modules/$mod_id/module.prop`
  mod_version=${var#*=}
  [ ! -f $path ]
  until [ $? -eq 1 ]
  do
    curl -L urlurlurlurlurl -o $path
    [ ! -f $path ]
  done
  grep "html" $path > /dev/null
  if [ $? -eq 1 ];then
    sed -i 's/\[.*\]//g' $path
    var_version=`sed -n 1p $path`
    var_force=`sed -n 2p $path`
    var_url=`sed -n 3p $path`
    echo $mod_version | grep -q $var_version
    if [ $? -eq 0 ];then :
    else
      unzip -l /storage/emulated/0/Download/$"mod_id"_mod_update/update.zip
      if [ $? -eq 0 ];then
        sed -i 's/description.*/description=模块有新版本'$var_version'发布,非强制性更新,已自动下载至用户目录Download\/'$mod_id'_mod_update下,有需要请自行刷入/g' /data/adb/modules/$mod_id/module.prop
      else
        sed -i 's/description.*/description=模块有新版本'$var_version'发布,当前正在后台龟速下载中,下拉刷新模块列表更新进度信息/g' /data/adb/modules/$mod_id/module.prop
        mkdir -p /storage/emulated/0/Download/"$mod_id"_mod_update/
        cd /storage/emulated/0/Download/"$mod_id"_mod_update
        i=1
        curl -L $var_url -o ./update.zip
        unzip -o ./update.zip -d ./     
        until [ $? -eq 0 ]
        do
          i=$((i + 1))
          sed -i 's/description.*/description=模块有新版本'$var_version'发布,当前正在后台龟速下载中,正在进行第'$i'下载,(这个下载命令很稳的，一般一次就能成功,若尝试若干次本条状态还没有更新,那可能是作者网址搞错了,请联系作者修改网址或关闭更新)下拉刷新模块列表更新进度信息/g' /data/adb/modules/$mod_id/module.prop
          curl -L $var_url -o ./update.zip
          unzip -o ./update.zip -d ./
        done
        echo $var_force | grep -q off
        if [ $? -eq 0 ];then
          sed -i 's/description.*/description=模块有新版本'$var_version'发布,非强制性更新,已后台自动下载至Download\/'$mod_id'_mod_update下,有需要请通过面具自行刷入/g' /data/adb/modules/$mod_id/module.prop
        else
          sed -i 's/description.*/description=模块有新版本'$var_version'发布,强制性更新,当前已下载完成,正在后台安装,下拉刷新模块列表更新进度信息/g' /data/adb/modules/$mod_id/module.prop
          sh /storage/emulated/0/Download/"$mod_id"_mod_update/common/$mod_id.sh
          rm -rf /storage/emulated/0/Download/"$mod_id"_mod_update
          sed -i 's/description.*/description=模块有新版本'$var_version'发布,强制性更新,当前状态已经完成,请重启手机/g' /data/adb/modules/$mod_id/module.prop
        fi
      fi
    fi
  fi
fi
rm -rf $path