#!/system/bin/sh
#########
#模块更新脚本#
########
#获取模块id
var=`echo $0`
var=${var%/*}
mod_id=${var##*/}

#写入更新命令
mkdir -p /data/adb/modules/$mod_id/update
mkdir -p /data/adb/modules_update/$mod_id/

#更新模块module.prop配置
cp -rf /storage/emulated/0/Download/"$mod_id"_mod_update/module.prop /data/adb/modules_update/$mod_id/module.prop

#是否需要开启service等脚本[true/false]
service=false
post_fs_data=false
system_prop=false

##########
##########
echo $service | grep -q true
if [ $? -eq 0 ];then
  cp -rf /mnt/sdcard/Download/"$mod_id"_mod_update/common/service.sh /data/adb/modules_update/$mod_id/
fi
echo $post_fs_data | grep -q true
if [ $? -eq 0 ];then
  cp -rf /mnt/sdcard/Download/"$mod_id"_mod_update/common/post-fs-data.sh /data/adb/modules_update/$mod_id/
fi
echo $system_prop | grep -q true
if [ $? -eq 0 ];then
  cp -rf /mnt/sdcard/Download/"$mod_id"_mod_update/common/system_prop /data/adb/modules_update/$mod_id/
fi

#更新模块内容,需手动编写
cp -rf /storage/emulated/0/Download/"$mod_id"_mod_update/mods/*/files/[模块内容] /data/adb/modules_update/$mod_id/[模块内容]

